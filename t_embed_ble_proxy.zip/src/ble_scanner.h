#pragma once
namespace BLEScanner {
  void begin();
  void update();
}