#pragma once
namespace MenuSystem {
  void begin();
  void update();
}