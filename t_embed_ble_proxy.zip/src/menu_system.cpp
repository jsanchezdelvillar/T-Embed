#include "menu_system.h"
#include <Arduino.h>

void MenuSystem::begin() {
  // Init screen, encoder, and draw main menu
}

void MenuSystem::update() {
  // Poll encoder and redraw screen based on selection
}